"""Klasa przechowujaca funkcje"""

import math

class Funkcja:
  
    def __init__(self):
        """Konstruktor klasy Funkcja"""
        pass
    
    def wartosc(self, x):
        """Metoda obliczajaca wartosc funkcji w punkcie x"""
        wart = -1.0*math.sin(11.0*x+7.0)+math.sqrt(7.0+x*x)
        return wart